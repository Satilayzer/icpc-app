﻿async function loadSubmissions() {
    const apiRequest = document.getElementById('apiRequests').value; // Получаем выбранный API
    const institution = document.getElementById('institution').value;
    const level = document.getElementById('level').value;
    const language = document.getElementById('language').value;

    const params = new URLSearchParams();
    if (institution) params.append('institution', institution);
    if (level) params.append('level', level);
    if (language) params.append('language', language);

    const response = await fetch(`http://localhost:3000/${apiRequest}?${params}`);
    const data = await response.json();

    const tbody = document.getElementById('results');
    tbody.innerHTML = '';
    data.forEach(sub => {
        const row = `
            <tr>
                <td>${sub.team || '-'}</td>
                <td>${sub.institution || '-'}</td>
                <td>${sub.education_level || '-'}</td>
                <td>${sub.language || '-'}</td>
                <td>${sub.problem_code || '-'}</td>
                <td>${sub.verdict || '-'}</td>
                <td>${new Date(sub.submission_time).toLocaleString() || '-'}</td>
            </tr>`;
        tbody.innerHTML += row;
    });
}
// Показывать/скрывать текстовое поле
function toggleTextFieldVisibility() {
    const textField = document.getElementById('apiTextField');
    const button = document.getElementById('toggleTextField');

    if (textField.style.display === 'none' || textField.style.display === '') {
        textField.style.display = 'inline'; // Показываем текстовое поле
        button.textContent = 'Скрыть поле'; // Обновляем текст кнопки
    } else {
        textField.style.display = 'none'; // Скрываем текстовое поле
        button.textContent = 'Показать поле'; // Обновляем текст кнопки
    }
}

// Обновляем значение текстового поля при изменении выбора API
document.getElementById('apiRequests').addEventListener('change', function () {
    const selectedApi = this.value;
    const textField = document.getElementById('apiTextField');
    textField.value = `Выбранный API: ${selectedApi}`; // Обновляем текст в текстовом поле
});

// Загружаем маршруты API из сервера
async function fetchRoutes() {
    try {
        // Делаем запрос на сервер для получения всех маршрутов
        const response = await fetch('http://localhost:3000/routes');
        const routes = await response.json();

        // Находим dropdown меню
        const apiRequestsDropdown = document.getElementById('apiRequests');

        // Очищаем dropdown перед заполнением
        apiRequestsDropdown.innerHTML = '';

        // Заполняем dropdown меню маршрутами
        routes.forEach(route => {
            const option = document.createElement('option');
            option.value = route;
            option.textContent = route;
            apiRequestsDropdown.appendChild(option);
        });

        // Устанавливаем первое значение в текстовом поле
        if (routes.length) {
            const textField = document.getElementById('apiTextField');
            textField.value = `Выбранный API: ${routes[0]}`;
        }
    } catch (error) {
        console.error('Ошибка загрузки маршрутов:', error);
    }
}

// Скрытие/показ таблицы и текстового поля на основе выбора из dropdown
document.getElementById('apiRequests').addEventListener('change', async function () {
    const selectedApi = this.value;
    const textField = document.getElementById('apiTextField');
    const table = document.querySelector('table');
    const results = document.getElementById('results');

    // Скрыть таблицу и показать текстовое поле
    table.style.display = 'none';
    textField.style.display = 'inline';

    // Отображать выбранный маршрут в текстовом поле
    textField.value = `Выбранный API: ${selectedApi}`;

    // Выполняем вызов API для получения данных
    try {
        const response = await fetch(`http://localhost:3000/${selectedApi}`);

        if (!response.ok) {
            throw new Error(`Ошибка: ${response.statusText}`);
        }

        const data = await response.json();

        // Отобразить данные в формате JSON в текстовом поле
        textField.value = JSON.stringify(data, null, 2);

    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        textField.value = 'Ошибка загрузки данных';
    }
});

// Показывать/скрывать текстовое поле (старый обработчик кнопки)
function toggleTextFieldVisibility() {
    const textField = document.getElementById('apiTextField');
    const button = document.getElementById('toggleTextField');

    if (textField.style.display === 'none' || textField.style.display === '') {
        textField.style.display = 'inline'; // Показываем текстовое поле
        button.textContent = 'Скрыть поле'; // Обновляем текст кнопки
    } else {
        textField.style.display = 'none'; // Скрываем текстовое поле
        button.textContent = 'Показать поле'; // Обновляем текст кнопки
    }
}

// Загружаем маршруты при загрузке страницы
window.addEventListener('DOMContentLoaded', () => {
    fetchRoutes();
});